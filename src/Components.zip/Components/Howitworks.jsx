import React from 'react'
import youtube_icon from './youtube_icon.png';
import appointment from './appointment.png';
import treatment from './treatment.png';

export default function Howitworks() {
  return (
    <>
        <div className="col-12 text-center my-10">
              <h1 className="fw-bold" style={{marginBottom:'56px',marginTop:'10vh'}}>How It Works</h1>
            </div>

            <div className="containerr" style={{display:'flex',flexDirection:'row',justifyContent:'space-around'}}>
            <div
                  className="col-lg-4 col-md-6 col-sm-12 col-12"
                  style={{ display:'flex',flexDirection:'column',justifyContent:'center',alignItems:'center',marginBottom: "22vh", borderRadius: "12px",border:'2px solid #d0d0d0',width:'25vw',height:'50vh', boxShadow:'rgb(214, 214, 214) 1px 2px 2px 0px',
                  border: '1px solid rgb(241, 241, 241)'  }}
                >
                <img src={youtube_icon} style={{width:'5vw',height:'7vh',marginBottom:'0.8rem'}}alt="" / >
                <h2 style={{fontSize:'1.7rem'}}> Watch Expert Videos</h2>
                
                <div className="para" style={{color:'#454545',fontSize:'1.1rem',maxWidth:'20vw',maxHeight:'25vh',textAlign:'center'}}>
                <p>Find valuable health advice from our trusted doctors</p>
                </div>
              
                </div>
                <div
                  className="col-lg-4 col-md-6 col-sm-12 col-12"
                  style={{ display:'flex',flexDirection:'column',justifyContent:'center',alignItems:'center',marginBottom: "20px", borderRadius: "12px",border:'2px solid #d0d0d0',width:'25vw',height:'50vh', boxShadow:'rgb(214, 214, 214) 1px 2px 2px 0px',
                  border: '1px solid rgb(241, 241, 241)'  }}
                >
                  <img src={appointment} style={{width:'3.5vw',height:'6vh',marginBottom:'0.8rem'}}alt="" / >
                 <h2 style={{fontSize:'1.7rem'}}> Book an Apointment</h2>
                 <div className="para" style={{color:'#454545',fontSize:'1.1rem',maxWidth:'20vw',maxHeight:'25vh',textAlign:'center'}}>
                <p>Find valuable health advice from our trusted doctors</p>
                </div>
                </div>
                <div
                  className="col-lg-4 col-md-6 col-sm-12 col-12"
                  style={{ display:'flex',flexDirection:'column',justifyContent:'center',alignItems:'center',marginBottom: "20px", borderRadius: "12px",border:'2px solid #d0d0d0',width:'25vw',height:'50vh', boxShadow:'rgb(214, 214, 214) 1px 2px 2px 0px',
                  border: '1px solid rgb(241, 241, 241)'  }}
                >
                    <img src={treatment} style={{width:'3.5vw',height:'6vh',marginBottom:'0.8rem'}}alt="" / >
                  <h2 style={{fontSize:'1.7rem'}}> Get Treatment</h2>
                  <div className="para" style={{color:'#454545',fontSize:'1.1rem',maxWidth:'20vw',maxHeight:'25vh',textAlign:'center'}}>
                <p >Find valuable health advice from our trusted doctors</p>
                </div>
                </div>
                </div>

    </>
  )
}
